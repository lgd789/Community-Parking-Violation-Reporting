//package kr.ac.mmu;
//
//import android.util.Log;
//
//public class Comment {
//    private String userId;
//    private String date;
//    private String content;
//
//    public Comment(String userId, String date, String content) {
//        this.userId = userId;
//        this.date = date;
//        this.content = content;
//        Log.d("aaaa", content);
//    }
//
//    public String getuserId() {
//        return userId;
//    }
//
//    public String getdate() {
//        return date;
//    }
//
//    public String getcontent() {
//        return content;
//    }
//}
